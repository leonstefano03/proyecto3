-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Servidor: mysql:3306
-- Tiempo de generación: 22-06-2025 a las 02:48:00
-- Versión del servidor: 5.7.44
-- Versión de PHP: 8.2.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `hexagonal`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categories`
--

CREATE TABLE `categories` (
  `id` int(10) NOT NULL,
  `name` varchar(255) CHARACTER SET latin1 NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `categories`
--

INSERT INTO `categories` (`id`, `name`, `date`) VALUES
(4, 'falopa', '2025-06-22 02:46:45'),
(5, 'AcciÃ³n', '2025-06-22 02:46:45'),
(6, 'Comedia', '2025-06-22 02:46:45'),
(7, 'Drama', '2025-06-22 02:46:45'),
(8, 'Ciencia FicciÃ³n', '2025-06-22 02:46:45'),
(9, 'Terror', '2025-06-22 02:46:45'),
(10, 'Documental', '2025-06-22 02:46:45'),
(11, 'AnimaciÃ³n', '2025-06-22 02:46:45'),
(12, 'FantasÃ­a', '2025-06-22 02:46:45');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `entertainment_id` int(11) DEFAULT NULL,
  `author` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `content` text CHARACTER SET latin1 NOT NULL,
  `date` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `comments`
--

INSERT INTO `comments` (`id`, `entertainment_id`, `author`, `content`, `date`) VALUES
(1, 10, 'leon', 'hola', '2025-06-21 22:29:58'),
(2, 10, 'leon', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque rem magnam, quaerat cupiditate doloremque voluptatum repudiandae distinctio, consectetur saepe consequatur veniam aperiam debitis nemo non reiciendis culpa sint molestias doloribus.', '2025-06-21 22:41:23'),
(5, 10, 'AnÃ³nimo', 'Buenisima serie', '2025-06-21 22:58:27'),
(6, 8, 'AnÃ³nimo', 'buena serie', '2025-06-22 01:58:27'),
(9, 24, 'leon', 'excelente peli de terror', '2025-06-22 02:43:54');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entertainments`
--

CREATE TABLE `entertainments` (
  `id` int(10) NOT NULL,
  `name` varchar(150) CHARACTER SET latin1 NOT NULL COMMENT 'title',
  `type` int(1) NOT NULL COMMENT '0 = movie;1 = serie',
  `date` datetime NOT NULL,
  `description` text CHARACTER SET latin1 NOT NULL,
  `category_id` int(10) NOT NULL,
  `is_final` int(1) NOT NULL,
  `image_url` text CHARACTER SET latin1 NOT NULL,
  `release_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `entertainments`
--

INSERT INTO `entertainments` (`id`, `name`, `type`, `date`, `description`, `category_id`, `is_final`, `image_url`, `release_date`) VALUES
(7, 'Inception', 1, '2025-06-21 21:06:18', 'Un ladrÃ³n que roba secretos a travÃ©s de los sueÃ±os.', 4, 1, '/src/uploads/ent_685720bcc13c7.jpg', '2010-07-16 00:00:00'),
(8, 'The Office', 2, '2025-06-21 21:06:18', 'Una sÃ¡tira de la vida de oficina.', 6, 1, '/src/uploads/ent_685720c5c2f6a.jpg', '2005-03-24 00:00:00'),
(9, 'Interstellar', 1, '2025-06-21 21:06:18', 'Viaje espacial en busca de esperanza para la humanidad.', 4, 1, '/src/uploads/ent_685720cfaf17f.jpg', '2014-11-07 00:00:00'),
(10, 'Breaking Bad', 2, '2025-06-21 21:06:18', 'Un profesor de quÃ­mica se convierte en narcotraficante.', 7, 1, '/src/uploads/ent_685720d93892f.png', '2008-01-20 00:00:00'),
(12, 'Toy Story', 1, '2025-06-21 21:06:18', 'Los juguetes cobran vida cuando no los ves.', 11, 1, '/src/uploads/ent_685720ec1a3da.jpg', '1995-11-22 00:00:00'),
(13, 'Stranger Things', 2, '2025-06-21 21:06:18', 'Misterios paranormales en un pueblo de EE.UU.', 8, 0, '/src/uploads/ent_685720ffd6145.jpg', '2016-07-15 00:00:00'),
(14, 'The Conjuring', 1, '2025-06-21 21:06:18', 'Investigadores paranormales enfrentan una entidad maligna.', 9, 1, '/src/uploads/ent_685721099d930.jpg', '2013-07-19 00:00:00'),
(15, 'Mad Max: Fury Road', 1, '2025-06-21 21:16:35', 'Un futuro post-apocalÃ­ptico dominado por guerra y supervivencia.', 5, 1, '/src/uploads/ent_6857238a8f94e.jpg', '2015-05-15 00:00:00'),
(16, 'John Wick', 1, '2025-06-21 21:16:35', 'Un asesino retirado regresa por venganza.', 5, 1, '/src/uploads/ent_685723a179460.webp', '2014-10-24 00:00:00'),
(17, 'Brooklyn Nine-Nine', 2, '2025-06-21 21:16:35', 'PolicÃ­as de Nueva York con humor absurdo y trabajo en equipo.', 6, 1, '/src/uploads/ent_685723b4b8b8d.jpg', '2013-09-17 00:00:00'),
(18, 'Friends', 2, '2025-06-21 21:16:35', 'Seis amigos enfrentan la vida, el amor y la risa en Nueva York.', 6, 1, '/src/uploads/ent_685723c77844a.jpg', '1994-09-22 00:00:00'),
(19, 'The Crown', 2, '2025-06-21 21:16:35', 'Relato histÃ³rico sobre la monarquÃ­a britÃ¡nica.', 7, 0, '/src/uploads/ent_685723e165da8.jpg', '2016-11-04 00:00:00'),
(20, 'The Godfather', 1, '2025-06-21 21:16:35', 'El ascenso de una familia mafiosa en EE.UU.', 7, 1, '/src/uploads/ent_685723f39ea4f.png', '1972-03-24 00:00:00'),
(21, 'Blade Runner 2049', 1, '2025-06-21 21:16:35', 'Un blade runner descubre un secreto que cambiarï¿½ la sociedad.', 4, 1, '/src/uploads/ent_68572403dc0af.jpeg', '2017-10-06 00:00:00'),
(22, 'Black Mirror', 2, '2025-06-21 21:16:35', 'Serie antolÃ³gica sobre tecnologÃ­a y distopÃ­as modernas.', 4, 0, '/src/uploads/ent_6857254624d13.jpg', '2011-12-04 00:00:00'),
(23, 'Hereditary', 1, '2025-06-21 21:16:35', 'Una familia descubre oscuros secretos tras la muerte de la abuela.', 9, 1, '/src/uploads/ent_685725556547c.jpg', '2018-06-08 00:00:00'),
(24, 'The Haunting of Hill House', 1, '2025-06-21 21:16:35', 'Una familia marcada por el trauma de su casa embrujada.', 5, 1, '/src/uploads/ent_68572560ce327.jpg', '2018-10-12 00:00:00'),
(25, 'Making a Murderer', 1, '2025-06-21 21:16:35', 'Un caso judicial real que cuestiona el sistema de justicia.', 10, 1, '/src/uploads/ent_68572571bf38d.jpg', '2015-12-18 00:00:00'),
(26, 'Cosmos: A Spacetime Odyssey', 2, '2025-06-21 21:16:35', 'Explora el universo y la ciencia con Neil deGrasse Tyson.', 10, 1, '/src/uploads/ent_6857257d8ed0b.jpg', '2014-03-09 00:00:00'),
(27, 'Spirited Away', 1, '2025-06-21 21:16:35', 'Una niÃ±a entra a un mundo espiritual tras perderse.', 11, 1, '/src/uploads/ent_685725959867d.jpg', '2001-07-20 00:00:00'),
(28, 'Rick and Morty', 2, '2025-06-21 21:16:35', 'Ciencia loca, humor negro y realidades paralelas.', 11, 0, '/src/uploads/ent_685725a3a9074.jpg', '2013-12-02 00:00:00'),
(29, 'Game of Thrones', 2, '2025-06-21 21:16:35', 'Reinos luchan por el poder en un mundo medieval fantÃ¡stico.', 8, 1, '/src/uploads/ent_685725b778947.jpg', '2011-04-17 00:00:00'),
(30, 'The Lord of the Rings: The Fellowship of the Ring', 1, '2025-06-21 21:16:35', 'Un joven hobbit debe destruir un anillo maligno.', 8, 1, '/src/uploads/ent_685725c307037.jpg', '2001-12-19 00:00:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(250) CHARACTER SET latin1 NOT NULL,
  `username` varchar(200) CHARACTER SET latin1 DEFAULT NULL,
  `password` varchar(200) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `email`, `username`, `password`) VALUES
(1, 'leon@gmail.com', 'leon', '1');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `entertainments`
--
ALTER TABLE `entertainments`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `entertainments`
--
ALTER TABLE `entertainments`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
